/** @type {import('next').NextConfig} */
const nextConfig = {
	images: {
		domains: ['localhost', 'bettermonday.org'],
	},
}

module.exports = nextConfig
